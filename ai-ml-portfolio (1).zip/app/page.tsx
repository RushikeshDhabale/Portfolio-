"use client"

import { ThemeProvider } from "../src/components/theme-provider"

export default function SyntheticV0PageForDeployment() {
  return <ThemeProvider />
}