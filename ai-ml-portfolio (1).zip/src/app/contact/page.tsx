import Contact from "../components/Contact"

export default function ContactPage() {
  return <Contact />
}

