import Skills from "../components/Skills"

export default function SkillsPage() {
  return <Skills />
}

