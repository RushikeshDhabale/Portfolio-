"use client"

import { motion } from "framer-motion"

const About = () => {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-3xl font-bold mb-8 text-center text-blue-800 dark:text-blue-300"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          About Me
        </motion.h2>
        <motion.div
          className="max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <p className="text-lg mb-6 text-gray-700 dark:text-gray-300">
            I'm a B.Tech student at G.H. Raisoni College of Engineering in Nagpur, India, specializing in Computer
            Science and Engineering with a focus on AI & ML. With a CGPA of 8.80, I'm on track to graduate in 2025.
          </p>
          <p className="text-lg mb-6 text-gray-700 dark:text-gray-300">
            My expertise lies in AI-based software development, predictive modeling, and data visualization. I have
            hands-on experience with Python, R, SQL, Power BI, and Arduino, which I've applied in various projects and
            internships.
          </p>
          <p className="text-lg text-gray-700 dark:text-gray-300">
            I'm passionate about using technology to solve real-world problems and am always eager to take on new
            challenges in the field of AI and Data Science.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

export default About

