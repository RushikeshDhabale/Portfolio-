"use client"

import { motion } from "framer-motion"
import { Award, Briefcase } from "lucide-react"

const certifications = [
  "Python for Data Science and Analytics (Presidency Technologies)",
  "Advanced Excel and Power BI (Presidency Technologies)",
  "Machine Learning Algorithms with Python (Presidency Technologies)",
]

const internships = [
  { company: "Align InfoTech Pvt. Ltd.", location: "Nagpur", date: "Ongoing" },
  { company: "PYF and Dana Pani Foundation", location: "Nagpur", date: "June 2023" },
  { company: "InternLearn", location: "Nagpur", date: "August 2023" },
]

const CertificationsInternships = () => {
  return (
    <section className="py-20 bg-gray-100 dark:bg-gray-700">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
            <h2 className="text-3xl font-bold mb-6 text-blue-800 dark:text-blue-300 flex items-center">
              <Award className="mr-2" /> Certifications
            </h2>
            <ul className="space-y-4">
              {certifications.map((cert, index) => (
                <motion.li
                  key={index}
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  {cert}
                </motion.li>
              ))}
            </ul>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
            <h2 className="text-3xl font-bold mb-6 text-blue-800 dark:text-blue-300 flex items-center">
              <Briefcase className="mr-2" /> Internships
            </h2>
            <ul className="space-y-4">
              {internships.map((internship, index) => (
                <motion.li
                  key={index}
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <strong>{internship.company}</strong>
                  <br />
                  {internship.location} | {internship.date}
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default CertificationsInternships

