import { Github, Linkedin, Mail } from "lucide-react"

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white dark:bg-gray-800 dark:text-gray-100 py-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p>&copy; 2023 Rushikesh Raju Dhabale. All rights reserved.</p>
          </div>
          <div className="flex space-x-4">
            <a href="mailto:rushikeshdhabale21@gmail.com" className="hover:text-blue-400 transition-colors">
              <Mail />
            </a>
            <a
              href="https://www.linkedin.com/posts/vineet-yadav-3ba8a2252_hiring-dataanalyst-freshers-activity-7296242883714584576-XTpY?utm_source=social_share_send&utm_medium=android_app&rcm=ACoAAD5akUcBw-0o5tgu7AGyEp9G9RYOymUtt3Y&utm_campaign=whatsapp"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-blue-400 transition-colors"
            >
              <Linkedin />
            </a>
            <a
              href="https://github.com/RushikeshDhabale"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-blue-400 transition-colors"
            >
              <Github />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

