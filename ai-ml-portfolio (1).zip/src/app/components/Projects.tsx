"use client"

import { motion } from "framer-motion"

const projects = [
  {
    title: "Data Analysis on Indian clothing market",
    description:
      "Led a team in mining, cleaning, and analyzing large datasets. Performed web scraping and data collection from various sources. Conducted comprehensive data analysis to derive actionable insights. Created interactive and insightful visualizations using Power BI. Provided market insights through detailed data visualization, aiding strategic decision-making.",
  },
  {
    title: "Agro-Robot System",
    description:
      "Developed an autonomous farming robot to enhance agricultural productivity. Implemented navigation systems and data collection modules using Arduino and Python.",
  },
  {
    title: "Smart GPS Dust Bin",
    description:
      "Led a project to create GPS-enabled dustbins for waste management efficiency. Designed real-time tracking mechanisms to notify garbage trucks when bins are 90% full.",
  },
  {
    title: "Parkinson's Disease Prediction",
    description:
      "Built a predictive model using R to analyze health data and detect Parkinson's disease. Conducted research to improve patient outcomes through machine learning techniques.",
  },
  {
    title: "Offline Multitasking AI Model",
    description:
      "Engineered an AI solution using pre-trained models for offline functionality. Integrated voice commands and automated updates, making information accessible offline.",
  },
]

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-3xl font-bold mb-12 text-center text-gray-900 dark:text-gray-100"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Projects
        </motion.h2>
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-gray-100">{project.title}</h3>
              <p className="text-gray-600 dark:text-gray-300">{project.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Projects

