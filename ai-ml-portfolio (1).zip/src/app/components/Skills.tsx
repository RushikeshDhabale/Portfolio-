"use client"

import { motion } from "framer-motion"
import { Code, Database, BarChart, Brain, Terminal, FileSpreadsheet } from "lucide-react"

const skills = [
  { name: "Programming", icon: Code, items: ["Python", "C", "C++", "SQL"] },
  { name: "Data Science", icon: Brain, items: ["Numpy", "Pandas", "Matplotlib", "Scikit-learn"] },
  { name: "Databases", icon: Database, items: ["MySQL", "Advanced Excel", "Power Query"] },
  { name: "Visualization", icon: BarChart, items: ["Power BI", "Data Visualization Techniques"] },
  { name: "AI/ML", icon: Terminal, items: ["Pre-trained AI Models", "Ollama", "Llama", "Vosk Speech Recognizer"] },
  { name: "Other", icon: FileSpreadsheet, items: ["Arduino", "Robotics", "ChatGPT Prompt Integration"] },
]

const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-gray-100 dark:bg-gray-700">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-3xl font-bold mb-12 text-center text-blue-800 dark:text-blue-300"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Technical Skills
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="flex items-center mb-4">
                <skill.icon className="w-8 h-8 mr-3 text-blue-600 dark:text-blue-400" />
                <h3 className="text-xl font-semibold text-gray-800 dark:text-white">{skill.name}</h3>
              </div>
              <ul className="list-disc list-inside text-gray-600 dark:text-gray-300">
                {skill.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Skills

