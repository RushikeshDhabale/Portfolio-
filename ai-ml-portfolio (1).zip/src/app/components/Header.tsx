"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { DarkModeToggle } from "./DarkModeToggle"
import { usePathname } from "next/navigation"

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const isActive = (path: string) => pathname === path

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            RD
          </Link>
          <div className="hidden md:flex space-x-8 items-center">
            <Link
              href="/about"
              className={`${isActive("/about") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
            >
              About
            </Link>
            <Link
              href="/skills"
              className={`${isActive("/skills") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
            >
              Skills
            </Link>
            <Link
              href="/projects"
              className={`${isActive("/projects") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
            >
              Projects
            </Link>
            <Link
              href="/contact"
              className={`${isActive("/contact") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
            >
              Contact
            </Link>
            <DarkModeToggle />
          </div>
          <button className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <Link
              href="/about"
              className={`block ${isActive("/about") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
              onClick={toggleMenu}
            >
              About
            </Link>
            <Link
              href="/skills"
              className={`block ${isActive("/skills") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
              onClick={toggleMenu}
            >
              Skills
            </Link>
            <Link
              href="/projects"
              className={`block ${isActive("/projects") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
              onClick={toggleMenu}
            >
              Projects
            </Link>
            <Link
              href="/contact"
              className={`block ${isActive("/contact") ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-300"} hover:text-blue-600 dark:hover:text-blue-400 transition-colors`}
              onClick={toggleMenu}
            >
              Contact
            </Link>
            <div className="pt-2">
              <DarkModeToggle />
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}

export default Header

