"use client"

import Image from "next/image"
import { motion } from "framer-motion"
import { Mail, Phone, Linkedin } from "lucide-react"

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-6 py-20 relative">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center md:text-left"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gray-900 dark:text-gray-100">
                Rushikesh Raju Dhabale
              </h1>
              <p className="text-xl md:text-2xl mb-6 text-gray-600 dark:text-gray-300">AI & ML Specialist</p>
              <div className="space-y-3">
                <a
                  href="mailto:rushikeshdhabale21@gmail.com"
                  className="flex items-center justify-center md:justify-start text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  rushikeshdhabale21@gmail.com
                </a>
                <a
                  href="tel:9607112178"
                  className="flex items-center justify-center md:justify-start text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  +91 9607112178
                </a>
                <a
                  href="https://www.linkedin.com/posts/vineet-yadav-3ba8a2252_hiring-dataanalyst-freshers-activity-7296242883714584576-XTpY?utm_source=social_share_send&utm_medium=android_app&rcm=ACoAAD5akUcBw-0o5tgu7AGyEp9G9RYOymUtt3Y&utm_campaign=whatsapp"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center md:justify-start text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
                >
                  <Linkedin className="w-5 h-5 mr-2" />
                  LinkedIn Profile
                </a>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="flex justify-center md:justify-end"
            >
              <div className="relative w-64 h-64 md:w-80 md:h-80">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Profile%20photo-8i0EwLAHZ1TFVjyCrqHeVJA3ZEVZra.png"
                  alt="Rushikesh Dhabale"
                  fill
                  className="rounded-full object-cover shadow-lg border-4 border-white dark:border-gray-800"
                  priority
                />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero

